#ifndef STRONGHOLD_H
#define STRONGHOLD_H

#include <string>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>

const int MAX_NOBLES = 100;
const int MAX_MERCHANTS = 100;
const int MAX_PEASANTS = 1000;
const int MAX_SLAVES = 500;

class GameSaver {
public:
    static void saveGame(const std::string& filename,
        const class Population& pop,
        const class Economy& econ,
        const class ResourceEcosystem& res);

    static void loadGame(const std::string& filename,
        class Population& pop,
        class Economy& econ,
        class ResourceEcosystem& res);
};

class SocialClass {
protected:
    int population;
    std::string className;

public:
    SocialClass(const std::string& name, int pop = 0);
    virtual void addPeople(int count);
    virtual void displayStatus() const;
    virtual ~SocialClass() = default;

    int getPopulation() const { return population; }
};

class Nobles : public SocialClass {
public:
    Nobles(int pop = 0);
    void addPeople(int count) override;
};

class Merchants : public SocialClass {
public:
    Merchants(int pop = 0);
    void addPeople(int count) override;
};

class Peasants : public SocialClass {
public:
    Peasants(int pop = 0);
    void addPeople(int count) override;
};

class Slaves : public SocialClass {
public:
    Slaves(int pop = 0);
    void addPeople(int count) override;
};

class SocialStructure {
private:
    Nobles nobles;
    Merchants merchants;
    Peasants peasants;
    Slaves slaves;

public:
    SocialStructure();
    void addNobles(int count);
    void addMerchants(int count);
    void addPeasants(int count);
    void addSlaves(int count);
    void displayStatus() const;
};

class Population {
private:
    int totalPeople;
    int births;
    int deaths;
    int unrestLevel;

public:
    Population();
    void grow(int births);
    void die(int deaths);
    void updateUnrest();
    void displayStatus() const;

    int getTotal() const { return totalPeople; }
};

class Army {
private:
    int totalSoldiers;
    int trainedSoldiers;
    int morale; // 0 to 100

public:
    Army();
    void recruit(int recruits);
    void train(int trainingSessions);
    void updateMorale();
    void displayStatus() const;
    void applyCasualties(int losses); 
};

class Leader {
private:
    std::string name;
    int leadershipLevel;
    int popularity;

public:
    Leader();
    void setName(const std::string& leaderName);
    void improveLeadership(int amount);
    void changePopularity(int amount);
    void displayStatus() const;
};

class Economy {
private:
    int gold;
    int food;

public:
    Economy();
    void addGold(int amount);
    void spendGold(int amount);
    void addFood(int amount);
    void consumeFood(int amount);
    void displayStatus() const;
    int getGold() const;
    void setGold(int amount);

    int getFood() const { return food; }
};

class Banking {
private:
    int totalLoans;
    int interestRate;

public:
    Banking();
    void issueLoan(int amount);
    void repayLoan(int amount);
    void adjustInterestRate(int newRate);
    void displayStatus() const;
};

class Corruption {
private:
    int corruptionLevel;

public:
    Corruption();
    void increaseCorruption(int amount);
    void decreaseCorruption(int amount);
    void displayStatus() const;
};

class Defense {
private:
    int wallStrength;
    int towerCount;
    int trapEfficiency;

public:
    Defense();
    void upgradeWalls(int amount);
    void addTowers(int count);
    void improveTraps(int amount);
    void displayStatus() const;
};

class ResourceEcosystem {
private:
    int food;
    int wood;
    int stone;
    int iron;

public:
    ResourceEcosystem();
    void gatherFood(int amount);
    void gatherWood(int amount);
    void gatherStone(int amount);
    void gatherIron(int amount);
    void consumeFood(int amount);
    void consumeWood(int amount);
    void consumeStone(int amount);
    void consumeIron(int amount);
    void displayStatus() const;

    void gatherResources(int f, int w, int s, int i);
    void consumeResources(int f, int w, int s, int i);
    void tradeResources(int& gold, int f, int w, int s, int i);

    int getFood() const { return food; }
    int getWood() const { return wood; }
    int getStone() const { return stone; }
    int getIron() const { return iron; }
};

class EventSystem {
public:
    static void checkRandomEvent(class Population& pop,
        class Economy& econ,
        class Army& army) {
        if (std::rand() % 5 == 0) { 
            int event = std::rand() % 3;
            switch (event) {
            case 0:
                std::cout << "\nEVENT: Bountiful harvest! +100 food\n";
                econ.addFood(100);
                break;
            case 1:
                std::cout << "\nEVENT: Bandit attack! -5 soldiers\n";
                army.recruit(-5);
                break;
            case 2:
                std::cout << "\nEVENT: Population boom! +50 people\n";
                pop.grow(50);
                break;
            }
        }
    }
};

#endif 