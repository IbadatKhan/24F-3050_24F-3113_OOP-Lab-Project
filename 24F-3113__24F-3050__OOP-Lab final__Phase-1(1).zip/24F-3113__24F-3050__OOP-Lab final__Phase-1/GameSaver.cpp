#include "Stronghold.h"

void GameSaver::saveGame(const std::string& filename,
    const Population& pop,
    const Economy& econ,
    const ResourceEcosystem& res) {
    std::ofstream out(filename);
    if (out) {
        out << pop.getTotal() << " "
            << econ.getGold() << " "
            << res.getFood() << " "
            << res.getWood() << " "
            << res.getStone() << " "
            << res.getIron() << "\n";
    }
}

void GameSaver::loadGame(const std::string& filename,
    Population& pop,
    Economy& econ,
    ResourceEcosystem& res) {
    std::ifstream in(filename);
    if (in) {
        int totalPop, gold, food, wood, stone, iron;
        in >> totalPop >> gold >> food >> wood >> stone >> iron;
        econ.setGold(gold);
        
    }
}