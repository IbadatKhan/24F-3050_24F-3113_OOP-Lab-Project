#include "Stronghold.h"

ResourceEcosystem::ResourceEcosystem() : food(0), wood(0), stone(0), iron(0) {}

void ResourceEcosystem::gatherFood(int amount) {
    if (amount > 0) {
        food += amount;
        std::cout << amount << " units of food gathered.\n";
    }
    else {
        std::cout << "Invalid amount.\n";
    }
}

void ResourceEcosystem::gatherWood(int amount) {
    if (amount > 0) {
        wood += amount;
        std::cout << amount << " units of wood gathered.\n";
    }
    else {
        std::cout << "Invalid amount.\n";
    }
}

void ResourceEcosystem::gatherStone(int amount) {
    if (amount > 0) {
        stone += amount;
        std::cout << amount << " units of stone gathered.\n";
    }
    else {
        std::cout << "Invalid amount.\n";
    }
}

void ResourceEcosystem::gatherIron(int amount) {
    if (amount > 0) {
        iron += amount;
        std::cout << amount << " units of iron gathered.\n";
    }
    else {
        std::cout << "Invalid amount.\n";
    }
}

void ResourceEcosystem::consumeFood(int amount) {
    if (amount > 0 && amount <= food) {
        food -= amount;
        std::cout << amount << " units of food consumed.\n";
    }
    else {
        std::cout << "Not enough food to consume.\n";
    }
}

void ResourceEcosystem::consumeWood(int amount) {
    if (amount > 0 && amount <= wood) {
        wood -= amount;
        std::cout << amount << " units of wood consumed.\n";
    }
    else {
        std::cout << "Not enough wood to consume.\n";
    }
}

void ResourceEcosystem::consumeStone(int amount) {
    if (amount > 0 && amount <= stone) {
        stone -= amount;
        std::cout << amount << " units of stone consumed.\n";
    }
    else {
        std::cout << "Not enough stone to consume.\n";
    }
}

void ResourceEcosystem::consumeIron(int amount) {
    if (amount > 0 && amount <= iron) {
        iron -= amount;
        std::cout << amount << " units of iron consumed.\n";
    }
    else {
        std::cout << "Not enough iron to consume.\n";
    }
}

void ResourceEcosystem::gatherResources(int f, int w, int s, int i) {
    gatherFood(f);
    gatherWood(w);
    gatherStone(s);
    gatherIron(i);
}

void ResourceEcosystem::consumeResources(int f, int w, int s, int i) {
    consumeFood(f);
    consumeWood(w);
    consumeStone(s);
    consumeIron(i);
}

void ResourceEcosystem::tradeResources(int& gold, int f, int w, int s, int i) {
    
    int cost = f * 2 + w * 3 + s * 5 + i * 10;
    if (gold >= cost) {
        gold -= cost;
        food += f;
        wood += w;
        stone += s;
        iron += i;
        std::cout << "Trade successful! Resources added to your stock.\n";
    }
    else {
        std::cout << "Not enough gold for this trade.\n";
    }
}

void ResourceEcosystem::displayStatus() const {
    std::cout << "\n--- Resource Ecosystem Status ---\n";
    std::cout << "Food: " << food << "\n";
    std::cout << "Wood: " << wood << "\n";
    std::cout << "Stone: " << stone << "\n";
    std::cout << "Iron: " << iron << "\n";
}