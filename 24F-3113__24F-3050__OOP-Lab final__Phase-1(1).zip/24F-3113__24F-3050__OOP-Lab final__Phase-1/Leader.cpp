

#include <iostream>
#include "Stronghold.h"

using namespace std;

Leader::Leader() {
    name = "Unnamed Leader";
    leadershipLevel = 50; 
    popularity = 50;      
}

void Leader::setName(const string& leaderName) {
    name = leaderName;
}

void Leader::improveLeadership(int amount) {
    if (amount > 0) {
        leadershipLevel += amount;
        if (leadershipLevel > 100) leadershipLevel = 100;
        cout << "Leadership level improved by " << amount << "." << endl;
    }
}

void Leader::changePopularity(int amount) {
    popularity += amount;
    if (popularity > 100) popularity = 100;
    if (popularity < 0) popularity = 0;
    cout << "Popularity changed by " << amount << "." << endl;
}

void Leader::displayStatus() const {
    cout << "Leader Name: " << name << endl;
    cout << "Leadership Level: " << leadershipLevel << "/100" << endl;
    cout << "Popularity: " << popularity << "/100" << endl;
}
