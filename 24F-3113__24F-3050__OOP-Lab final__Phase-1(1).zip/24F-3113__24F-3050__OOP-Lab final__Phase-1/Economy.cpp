#include <iostream>
#include "Stronghold.h"

using namespace std;

Economy::Economy() {
    gold = 1000; // Starting gold
    food = 500;  // Starting food
}

void Economy::addGold(int amount) {
    if (amount > 0) {
        gold += amount;
        cout << "Added " << amount << " gold." << endl;
    }
}

void Economy::spendGold(int amount) {
    if (amount > 0 && amount <= gold) {
        gold -= amount;
        cout << "Spent " << amount << " gold." << endl;
    }
    else {
        cout << "Not enough gold to spend." << endl;
    }
}

void Economy::addFood(int amount) {
    if (amount > 0) {
        food += amount;
        cout << "Added " << amount << " food." << endl;
    }
}

void Economy::consumeFood(int amount) {
    if (amount > 0 && amount <= food) {
        food -= amount;
        cout << "Consumed " << amount << " food." << endl;
    }
    else {
        cout << "Not enough food to consume." << endl;
    }
}

void Economy::displayStatus() const {
    cout << "Gold: " << gold << endl;
    cout << "Food: " << food << endl;
}

// ? Newly added methods
int Economy::getGold() const {
    return gold;
}

void Economy::setGold(int amount) {
    if (amount >= 0) {
        gold = amount;
    }
}
