#include "Stronghold.h"

SocialClass::SocialClass(const std::string& name, int pop)
    : className(name), population(pop) {}

void SocialClass::addPeople(int count) {
    population += count;
}

void SocialClass::displayStatus() const {
    std::cout << className << ": " << population << " people\n";
}

Nobles::Nobles(int pop) : SocialClass("Nobles", pop) {}
void Nobles::addPeople(int count) {
    if (population + count <= MAX_NOBLES) {
        population += count;
    }
    else {
        std::cout << "Cannot add more Nobles. Maximum capacity reached.\n";
    }
}

Merchants::Merchants(int pop) : SocialClass("Merchants", pop) {}
void Merchants::addPeople(int count) {
    if (population + count <= MAX_MERCHANTS) {
        population += count;
    }
    else {
        std::cout << "Cannot add more Merchants. Maximum capacity reached.\n";
    }
}

Peasants::Peasants(int pop) : SocialClass("Peasants", pop) {}
void Peasants::addPeople(int count) {
    if (population + count <= MAX_PEASANTS) {
        population += count;
    }
    else {
        std::cout << "Cannot add more Peasants. Maximum capacity reached.\n";
    }
}

Slaves::Slaves(int pop) : SocialClass("Slaves", pop) {}
void Slaves::addPeople(int count) {
    if (population + count <= MAX_SLAVES) {
        population += count;
    }
    else {
        std::cout << "Cannot add more Slaves. Maximum capacity reached.\n";
    }
}

SocialStructure::SocialStructure()
    : nobles(0), merchants(0), peasants(0), slaves(0) {}

void SocialStructure::addNobles(int count) {
    nobles.addPeople(count);
}

void SocialStructure::addMerchants(int count) {
    merchants.addPeople(count);
}

void SocialStructure::addPeasants(int count) {
    peasants.addPeople(count);
}

void SocialStructure::addSlaves(int count) {
    slaves.addPeople(count);
}

void SocialStructure::displayStatus() const {
    std::cout << "Social Structure Status:\n";
    nobles.displayStatus();
    merchants.displayStatus();
    peasants.displayStatus();
    slaves.displayStatus();
}
