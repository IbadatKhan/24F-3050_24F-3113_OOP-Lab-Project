

#include "Stronghold.h"

Defense::Defense() : wallStrength(0), towerCount(0), trapEfficiency(0) {}


void Defense::upgradeWalls(int amount) {
    if (amount > 0) {
        wallStrength += amount;
        std::cout << amount << " wall strength increased.\n";
    }
    else {
        std::cout << "Invalid wall strength.\n";
    }
}

void Defense::addTowers(int count) {
    if (count > 0) {
        towerCount += count;
        std::cout << count << " towers added.\n";
    }
    else {
        std::cout << "Invalid number of towers.\n";
    }
}


void Defense::improveTraps(int amount) {
    if (amount > 0) {
        trapEfficiency += amount;
        std::cout << amount << " trap efficiency increased.\n";
    }
    else {
        std::cout << "Invalid trap improvement.\n";
    }
}

void Defense::displayStatus() const {
    std::cout << "\n--- Defense Status ---\n";
    std::cout << "Wall Strength: " << wallStrength << "\n";
    std::cout << "Tower Count: " << towerCount << "\n";
    std::cout << "Trap Efficiency: " << trapEfficiency << "\n";
}
